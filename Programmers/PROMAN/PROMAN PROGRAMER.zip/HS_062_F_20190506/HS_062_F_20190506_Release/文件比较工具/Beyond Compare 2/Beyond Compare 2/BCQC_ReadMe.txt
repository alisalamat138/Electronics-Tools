QuickCompare for Beyond Compare 2
version 1.0, released 11-Aug-2005
Copyright (c) 2005 Scooter Software, Inc.


Abstract
--------

BCQC provides a command line comparison using size, crc, binary, 
or rules-based criteria.  The result of the comparison is returned as
a DOS error level.

BCQC replaces the old /quickcompare or /qc command line option for
Beyond Compare 2.  This replacement is because a Windows GUI program
isn't able to reliably set DOS error levels.

BCQC syntax (also available by running bcqc with no arguments): 

Syntax: bcqc [options] filename filename

Options:
  /size, /s                   = size-only comparison
  /crc, /c                    = CRC32 comparison
  /binary, /b                 = binary comparison
  /rules[=rules name], /r     = rules-based comparison
  /selftest                   = run a self test (omit filenames)

The /rules switch can optionally include the name of an
existing rules set.  If the rules name is omitted the rules
will be picked automatically based on the file names.

Comparison result is returned as the DOS ErrorLevel
  0 = files match
  1 = files only contain unimportant differences
  2 = files do not match
  3 = error, result unknown


Requirements
------------

A registered or trial version of Scooter Software's Beyond Compare version 2.


History
-------

08/11/05  v1.0.0
          Official release.


To Contact Us
-------------

If you have any questions, comments or suggestions, contact
support at:

	Scooter Software
	2828 Marshall Court, #112
	Madison, WI  53705-2276

	web site:  http://www.scootersoftware.com/
	email:     support@scootersoftware.com
